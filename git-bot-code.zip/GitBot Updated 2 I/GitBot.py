from tkinter import *
from PIL import Image, ImageTk
import webbrowser as browser
import os
from tkinter import messagebox
import shutil
from tkinter import filedialog

class Git:
 @staticmethod
 def config_git(user):
      cmd = "git config --global user.name "+user
      ret = os.system(cmd)
      if ret !=0:
             return 0
      else:
            return 1
 @staticmethod
 def init_git():
       cmd = "git init"
       ret = os.system(cmd)
       if ret != 0:
          return 0
       else:
         return 1
 @staticmethod
 def add_gitfile(fname):
      cmd = "git add "+fname
      ret = os.system(cmd)
      if ret!=0:
        return 0
      else:
         return 1
 @staticmethod
 def remote_config(user, rep):
       cmd = "git remote add origin https://github.com/"+user+"/"+rep+".git"
       ret = os.system(cmd)
       if ret !=0:
           return 0
       else:
         return 1

 @staticmethod
 def remote_unconfig(user):
       cmd = "git remote remove origin"
       ret = os.system(cmd)
       if ret !=0:
           return 0
       else:
         return 1

 @staticmethod
 def push_git():
       cmd = "git push -u -f origin master"
       ret = os.system(cmd)
       if ret !=0:
         return 0
       else:
         return 1

 @staticmethod
 def pull_git():
       cmd = 'git pull origin '+' "" '
       ret = os.system(cmd)
       if ret !=0:
             return 0
       else:
          return 1

 @staticmethod
 def git_commitfile(cstr):
       cmd = 'git commit -m '+' " '+cstr+' " '
       ret = os.system(cmd)
       if ret !=0:
             return 0
       else:
          return 1

class page_2x:
  @staticmethod
  def add_it(par_, user_, cl_):
      repo1 = StringVar()
      file1 = StringVar()
      master1 = StringVar()
      can1 = Canvas(par_, width="600", height="400", bg="#000000", highlightthickness=0)
      can1.place(x=300, y=200)
      lab1 = Label(can1, text="* Existed Resporitory Name:", bg="#000000", fg="#ffffff", font=("Arial", 8))
      lab1.place(x=60, y=30)
      et1 = Entry(can1, textvariable=repo1, bg="#000000", fg="#ffffff", font=("Arial", 10))
      et1.place(x=210, y=30)
      lab2 = Label(can1, text="* Add File:", bg="#000000", fg="#ffffff", font=("Arial", 8))
      lab2.place(x=60, y=60)
      et2 = Entry(can1, textvariable=file1, width="50", bg="#000000", fg="#ffffff", font=("Arial", 10))
      et2.place(x=130, y=60)
      btn1 = Label(can1, text="Browse", bg="#292929", fg="#ffffff", font=("Arial", 11))
      btn1.place(x=500, y=60)
      def b_e(e):
           btn1.config(bg="#d0940a")
      def b_l(e):
           btn1.config(bg="#292929")
      def b_b(e):
          fn =  filedialog.askopenfilename(title="Choose File", initialdir="/", filetypes=[("All Files", "*.*")])
          file1.set(fn)
      btn1.bind('<Enter>', b_e)
      btn1.bind('<Leave>', b_l)
      btn1.bind('<Button-1>', b_b)
      btn2 = Label(can1, text="Add", bg="#292929", fg="#ffffff", font=("Arial", 11))
      btn2.place(x=270, y=90)
      def bb_e(e):
           btn2.config(bg="#d0940a")
      def bb_l(e):
           btn2.config(bg="#292929")
      def bb_b(e):
           if repo1.get()=="":
                messagebox.showwarning("Error", "Please fill the respository name.")
           elif file1.get()=="":
                messagebox.showwarning("Error", "Please select the file.")
           else:
               os.chdir("~temp")
               mp = file1.get()
               p, f = os.path.split(file1.get())
               shutil.copy(mp,   f)
               r0 = Git.init_git() 
               r1= Git.remote_config(user_, repo1.get())
               if r0==1 and r1==1:
                  r2 = Git.add_gitfile(f)
                  if r2==1:
                       r3 = Git.git_commitfile("Add "+f+" a file.")
                       if r3==1:
                            r4 = Git.push_git()
                            if r4==1:
                                  messagebox.showinfo("Sucessful", "File Added sucessfully")
                                  Git.remote_unconfig(user_)
                                  os.chdir("..")
                                  
               else:
                  messagebox.showwarning("Error", "Problem with git.")
                           
      btn2.bind('<Enter>', bb_e)
      btn2.bind('<Leave>', bb_l)
      btn2.bind('<Button-1>', bb_b)
      lab3 = Label(can1, text="Download Path:", bg="#000000", fg="#ffffff", font=("Arial", 8))
      lab3.place(x=60, y=130)
      et3 = Entry(can1, textvariable=master1, state="disabled", width="50", fg="#000000", font=("Arial", 10))
      et3.place(x=155, y=130)
      master1.set("master")
      btn3 = Label(can1, text="Download", bg="#292929", fg="#ffffff", font=("Arial", 11))
      btn3.place(x=255, y=170)
      def bbb_e(e):
           btn3.config(bg="#d0940a")
      def bbb_l(e):
           btn3.config(bg="#292929")
      def bbb_b(e):
           if repo1.get()=="":
               messagebox.showwarning("Error", "Please fill the respository name.")
           else:
               os.chdir("~temp")
               r0 = Git.init_git() 
               r1= Git.remote_config(user_, repo1.get())
               if r0==1 and r1==1:
                  r2 = Git.pull_git()
                  if r2==1:
                        messagebox.showinfo("Sucessful", "Data downloaded sucessfully.")
                        Git.remote_unconfig(user_)
                        os.chdir("..")
                        
               else:
                    messagebox.showwarning("Error", "Problem with git.")
      btn3.bind('<Enter>', bbb_e)
      btn3.bind('<Leave>', bbb_l)
      btn3.bind('<Button-1>', bbb_b)
      btn4 = Label(can1, text="Log Out", bg="#292929", fg="#ffffff", font=("Arial", 11))
      btn4.place(x=275, y=370)
      def bbbb_e(e):
           btn4.config(bg="#d0940a")
      def bbbb_l(e):
           btn4.config(bg="#292929")
      def bbbb_b(e):
           messagebox.showinfo("Thank you", "After logout please use flush_git.bat and flush_main.bat either overloaded.\nThanks @Pranav")
           can1.place_forget()
           page_1x.add_it(par_, cl_)
           cl_.place(x=par_.winfo_screenwidth()-80, y=30)
      btn4.bind('<Enter>', bbbb_e)
      btn4.bind('<Leave>', bbbb_l)
      btn4.bind('<Button-1>', bbbb_b)
      
class page_1x:
  @staticmethod
  def add_it(par_, cl_):
      user1 = StringVar()
      can1 = Canvas(par_, width="600", height="400", bg="#000000", highlightthickness=0)
      can1.place(x=300, y=200)
      lab1 = Label(can1, text="Username:", bg="#000000", fg="#ffffff", font=("Arial", 8))
      lab1.place(x=60, y=30)
      et1 = Entry(can1, textvariable=user1, width="60", bg="#000000", fg="#ffffff", font=("Arial", 10))
      et1.place(x=130, y=30)
      btn1 = Label(can1, text="Log In", bg="#292929", fg="#ffffff", font=("Arial", 11))
      btn1.place(x=290, y=70)
      def b_e(e):
           btn1.config(bg="#d0940a")
      def b_l(e):
           btn1.config(bg="#292929")
      def b_b(e):
           if user1.get()=="":
                messagebox.showwarning("Error", "Please fill the username.")
           else:
               user_ = user1.get()
               ret = Git.config_git(user_)
               if ret==0:
                   messagebox.showwarning("Error", "Unable to configure.")
               else:
                os.mkdir("~temp")
                page_2x.add_it(par_, user_, cl_)
                can1.place_forget()
                cl_.place_forget()
      btn1.bind('<Enter>', b_e)
      btn1.bind('<Leave>', b_l)
      btn1.bind('<Button-1>', b_b)

class GitBot:
   @staticmethod
   def abt_():
           ax = Tk()
           ax.overrideredirect(1)
           ax.geometry("320x300+260+180")
           ax.configure(bg="#000000")
           def cp(e):
               ax.destroy()
           ax.bind('<Button-1>', cp)
           lab2  = Label(ax, text="Mr. Pranav", bg="#000000", fg="#ffffff", font=("Arial", 12))
           lab2.place(x=10, y=10)
           lab3 = Label(ax, text="There are lots of VPs and SVPs in google and microsoft, github", bg="#000000", fg="#ffffff", font=("Arial", 8))
           lab3.place(x=6, y=40)
           lab4 = Label(ax, text="almost 60 years above just search it with less age who is the ", bg="#000000", fg="#ffffff", font=("Arial", 8))
           lab4.place(x=6, y=60)
           lab5 = Label(ax, text="main boss of google and micrsoft & github, why he is google's", bg="#000000", fg="#ffffff", font=("Arial", 8))
           lab5.place(x=6, y=80)
           lab6 = Label(ax, text="microsoft or github main boss ?", bg="#000000", fg="#ffffff", font=("Arial", 8))
           lab6.place(x=6, y=100)
           ax.mainloop() 
   def create_main_ex():
       ttk = Tk()
       dx = ttk.winfo_screenwidth()
       dy = ttk.winfo_screenheight()
       ttk.geometry(("%dx%d")%(dx, dy))
       ttk.configure(bg="#000000")
       ttk.overrideredirect(1)
       ttk.attributes('-alpha', 0.9)
       img = Image.open("GitBot.png")
       img = img.resize((103, 65))
       global img_g
       img_g = ImageTk.PhotoImage(img)
       img_l = Label(ttk, image=img_g, width="103", height="65")
       img_l.place(x=100, y=100)
       def img_e(e):
          img_l.config(width="123", height="85")
       def img_lc(e):
         img_l.config(width="103", height="65")
       def img_b(e):
           GitBot.abt_()
       img_l.bind('<Enter>', img_e)
       img_l.bind('<Leave>', img_lc)
       img_l.bind('<Button-1>', img_b)
       lab = Label(ttk, text="Git Unofficial Bot", bg="#000000", fg="#ffffff", font=("Gills Sans", 18))
       lab.place(x=229, y=100)
       close_b = Label(ttk, text="×", bg="#000000", fg="#ffffff", font=("Cailibri Body", 12))
       close_b.place(x=dx-80, y=30)
       def c_e(e):
           close_b.config(fg="#d0940a", font=("Cailibri Body", 13))
       def c_l(e):
           close_b.config(fg="#ffffff", font=("Cailibri Body", 12))
       def c_b(e):
             ttk.destroy() 
       close_b.bind('<Enter>', c_e)
       close_b.bind('<Leave>', c_l)
       close_b.bind('<Button-1>', c_b)
       copy_r = Label(ttk, text="This is product owned by github under microsoft corporation, created by Pranav.", bg="#000000", fg="#ffffff", font=("Arial", 9))
       copy_r.place(x=(dx-600)/2, y=dy-60)
       def cr_e(e):
           copy_r.config(fg="#d0940a", font=("Arial", 11))
       def cr_l(e):
           copy_r.config(fg="#ffffff", font=("Arial", 9))
       def cr_b(e):
           browser.open("https://microsoft.com/")
           browser.open("https://github.com/Pranav00747")
       copy_r.bind('<Enter>', cr_e)
       copy_r.bind('<Leave>', cr_l)
       copy_r.bind('<Button-1>', cr_b)
       sp = Label(ttk, text="Special thanks to Sundar & Jeff Bezos and Jack team and Satya Nadella & Thomas.", bg="#000000", fg="#ffffff", font=("Arial", 8))
       sp.place(x=(dx-520)/2, y=dy-30)
       return ttk, close_b

if __name__=="__main__":
   gb = GitBot
   gbx, cl= gb.create_main_ex()
   ret = os.system("ping www.google.com") 
   if ret==0:
    page_1x.add_it(gbx, cl)
    gbx.mainloop()
   else:
      messagebox.showwarning("Error Connectivity", "Please check internet connection.")