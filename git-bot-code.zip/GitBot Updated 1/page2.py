from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import page1
import os
import Git
import shutil
import GitBot
class page_2x:
  @staticmethod
  def add_it(par_, user_, cl_):
      repo1 = StringVar()
      file1 = StringVar()
      master1 = StringVar()
      can1 = Canvas(par_, width="600", height="400", bg="#000000", highlightthickness=0)
      can1.place(x=300, y=200)
      lab1 = Label(can1, text="* Existed Resporitory Name:", bg="#000000", fg="#ffffff", font=("Arial", 8))
      lab1.place(x=60, y=30)
      et1 = Entry(can1, textvariable=repo1, bg="#000000", fg="#ffffff", font=("Arial", 10))
      et1.place(x=210, y=30)
      lab2 = Label(can1, text="* Add File:", bg="#000000", fg="#ffffff", font=("Arial", 8))
      lab2.place(x=60, y=60)
      et2 = Entry(can1, textvariable=file1, width="50", bg="#000000", fg="#ffffff", font=("Arial", 10))
      et2.place(x=130, y=60)
      btn1 = Label(can1, text="Browse", bg="#292929", fg="#ffffff", font=("Arial", 11))
      btn1.place(x=500, y=60)
      def b_e(e):
           btn1.config(bg="#d0940a")
      def b_l(e):
           btn1.config(bg="#292929")
      def b_b(e):
          fn =  filedialog.askopenfilename(title="Choose File", initialdir="/", filetypes=[("All Files", "*.*")])
          file1.set(fn)
      btn1.bind('<Enter>', b_e)
      btn1.bind('<Leave>', b_l)
      btn1.bind('<Button-1>', b_b)
      btn2 = Label(can1, text="Add", bg="#292929", fg="#ffffff", font=("Arial", 11))
      btn2.place(x=270, y=90)
      def bb_e(e):
           btn2.config(bg="#d0940a")
      def bb_l(e):
           btn2.config(bg="#292929")
      def bb_b(e):
           if repo1.get()=="":
                messagebox.showwarning("Error", "Please fill the respository name.")
           elif file1.get()=="":
                messagebox.showwarning("Error", "Please select the file.")
           else:
               os.chdir("~temp")
               mp = file1.get()
               p, f = os.path.split(file1.get())
               shutil.copy(mp,   f)
               r0 = Git.Git.init_git() 
               r1= Git.Git.remote_config(user_, repo1.get())
               if r0==1 and r1==1:
                  r2 = Git.Git.add_gitfile(f)
                  if r2==1:
                       r3 = Git.Git.git_commitfile("Add "+f+" a file.")
                       if r3==1:
                            r4 = Git.Git.push_git()
                            if r4==1:
                                  messagebox.showinfo("Sucessful", "File Added sucessfully")
                                  Git.Git.remote_unconfig(user_)
                                  os.chdir("..")
                                  
               else:
                  messagebox.showwarning("Error", "Problem with git.")
                           
      btn2.bind('<Enter>', bb_e)
      btn2.bind('<Leave>', bb_l)
      btn2.bind('<Button-1>', bb_b)
      lab3 = Label(can1, text="Download Path:", bg="#000000", fg="#ffffff", font=("Arial", 8))
      lab3.place(x=60, y=130)
      et3 = Entry(can1, textvariable=master1, state="disabled", width="50", fg="#000000", font=("Arial", 10))
      et3.place(x=155, y=130)
      master1.set("master")
      btn3 = Label(can1, text="Download", bg="#292929", fg="#ffffff", font=("Arial", 11))
      btn3.place(x=255, y=170)
      def bbb_e(e):
           btn3.config(bg="#d0940a")
      def bbb_l(e):
           btn3.config(bg="#292929")
      def bbb_b(e):
           if repo1.get()=="":
               messagebox.showwarning("Error", "Please fill the respository name.")
           else:
               os.chdir("~temp")
               r0 = Git.Git.init_git() 
               r1= Git.Git.remote_config(user_, repo1.get())
               if r0==1 and r1==1:
                  r2 = Git.Git.pull_git()
                  if r2==1:
                        messagebox.showinfo("Sucessful", "Data downloaded sucessfully.")
                        Git.Git.remote_unconfig(user_)
                        os.chdir("..")
                        
               else:
                    messagebox.showwarning("Error", "Problem with git.")
      btn3.bind('<Enter>', bbb_e)
      btn3.bind('<Leave>', bbb_l)
      btn3.bind('<Button-1>', bbb_b)
      btn4 = Label(can1, text="Log Out", bg="#292929", fg="#ffffff", font=("Arial", 11))
      btn4.place(x=275, y=370)
      def bbbb_e(e):
           btn4.config(bg="#d0940a")
      def bbbb_l(e):
           btn4.config(bg="#292929")
      def bbbb_b(e):
           messagebox.showinfo("Thank you", "After logout please use flush_git.bat and flush_main.bat either overloaded.\nThanks @Pranav")
           can1.place_forget()
           page1.page_1x.add_it(par_, cl_)
           cl_.place(x=par_.winfo_screenwidth()-80, y=30)
      btn4.bind('<Enter>', bbbb_e)
      btn4.bind('<Leave>', bbbb_l)
      btn4.bind('<Button-1>', bbbb_b)
      