import os

class Git:
 @staticmethod
 def config_git(user):
      cmd = "git config --global user.name "+user
      ret = os.system(cmd)
      if ret !=0:
             return 0
      else:
            return 1
 @staticmethod
 def init_git():
       cmd = "git init"
       ret = os.system(cmd)
       if ret != 0:
          return 0
       else:
         return 1
 @staticmethod
 def add_gitfile(fname):
      cmd = "git add "+fname
      ret = os.system(cmd)
      if ret!=0:
        return 0
      else:
         return 1
 @staticmethod
 def remote_config(user, rep):
       cmd = "git remote add origin https://github.com/"+user+"/"+rep+".git"
       ret = os.system(cmd)
       if ret !=0:
           return 0
       else:
         return 1

 @staticmethod
 def remote_unconfig(user):
       cmd = "git remote remove origin"
       ret = os.system(cmd)
       if ret !=0:
           return 0
       else:
         return 1

 @staticmethod
 def push_git():
       cmd = "git push -u -f origin master"
       ret = os.system(cmd)
       if ret !=0:
         return 0
       else:
         return 1

 @staticmethod
 def pull_git():
       cmd = 'git pull origin '+' "" '
       ret = os.system(cmd)
       if ret !=0:
             return 0
       else:
          return 1

 @staticmethod
 def git_commitfile(cstr):
       cmd = 'git commit -m '+' " '+cstr+' " '
       ret = os.system(cmd)
       if ret !=0:
             return 0
       else:
          return 1








