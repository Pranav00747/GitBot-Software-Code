from tkinter import *
from PIL import Image, ImageTk
import webbrowser as browser
import page1
import os
from tkinter import messagebox
class GitBot:
   @staticmethod
   def abt_():
           ax = Tk()
           ax.overrideredirect(1)
           ax.geometry("320x300+260+180")
           ax.configure(bg="#000000")
           def cp(e):
               ax.destroy()
           ax.bind('<Button-1>', cp)
           lab2  = Label(ax, text="Mr. Pranav", bg="#000000", fg="#ffffff", font=("Arial", 12))
           lab2.place(x=10, y=10)
           lab3 = Label(ax, text="There are lots of VPs and SVPs in google almost 60 years", bg="#000000", fg="#ffffff", font=("Arial", 8))
           lab3.place(x=6, y=40)
           lab4 = Label(ax, text="above just search it with less age who is the main boss of", bg="#000000", fg="#ffffff", font=("Arial", 8))
           lab4.place(x=6, y=60)
           lab5 = Label(ax, text="google, why he is google's main boss ?", bg="#000000", fg="#ffffff", font=("Arial", 8))
           lab5.place(x=6, y=80)
           ax.mainloop() 
   def create_main_ex():
       ttk = Tk()
       dx = ttk.winfo_screenwidth()
       dy = ttk.winfo_screenheight()
       ttk.geometry(("%dx%d")%(dx, dy))
       ttk.configure(bg="#000000")
       ttk.overrideredirect(1)
       ttk.attributes('-alpha', 0.9)
       img = Image.open("GitBot.png")
       img = img.resize((103, 65))
       global img_g
       img_g = ImageTk.PhotoImage(img)
       img_l = Label(ttk, image=img_g, width="103", height="65")
       img_l.place(x=100, y=100)
       def img_e(e):
          img_l.config(width="123", height="85")
       def img_lc(e):
         img_l.config(width="103", height="65")
       def img_b(e):
           GitBot.abt_()
       img_l.bind('<Enter>', img_e)
       img_l.bind('<Leave>', img_lc)
       img_l.bind('<Button-1>', img_b)
       lab = Label(ttk, text="Git Bot", bg="#000000", fg="#ffffff", font=("Gills Sans", 18))
       lab.place(x=229, y=100)
       close_b = Label(ttk, text="×", bg="#000000", fg="#ffffff", font=("Cailibri Body", 12))
       close_b.place(x=dx-80, y=30)
       def c_e(e):
           close_b.config(fg="#d0940a", font=("Cailibri Body", 13))
       def c_l(e):
           close_b.config(fg="#ffffff", font=("Cailibri Body", 12))
       def c_b(e):
             ttk.destroy() 
       close_b.bind('<Enter>', c_e)
       close_b.bind('<Leave>', c_l)
       close_b.bind('<Button-1>', c_b)
       copy_r = Label(ttk, text="Copyright of @Pranav", bg="#000000", fg="#ffffff", font=("Arial", 12))
       copy_r.place(x=(dx-230)/2, y=dy-60)
       def cr_e(e):
           copy_r.config(fg="#d0940a", font=("Arial", 13))
       def cr_l(e):
           copy_r.config(fg="#ffffff", font=("Arial", 12))
       def cr_b(e):
           browser.open("https://github.com/Pranav00747")
       copy_r.bind('<Enter>', cr_e)
       copy_r.bind('<Leave>', cr_l)
       copy_r.bind('<Button-1>', cr_b)
       sp = Label(ttk, text="Special thanks to Sundar & Jeff Bezos and Jack team", bg="#000000", fg="#ffffff", font=("Arial", 8))
       sp.place(x=(dx-340)/2, y=dy-30)
       return ttk, close_b

if __name__=="__main__":
   gb = GitBot
   gbx, cl= gb.create_main_ex()
   ret = os.system("ping www.google.com")
   if ret==0:
    page1.page_1x.add_it(gbx, cl)
    gbx.mainloop()
   else:
      messagebox.showwarning("Error Connectivity", "Please check internet connection.")