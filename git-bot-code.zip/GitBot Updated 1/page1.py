from tkinter import *
import page2
from tkinter import messagebox
import os
import shutil
import Git
import GitBot
class page_1x:
  @staticmethod
  def add_it(par_, cl_):
      user1 = StringVar()
      can1 = Canvas(par_, width="600", height="400", bg="#000000", highlightthickness=0)
      can1.place(x=300, y=200)
      lab1 = Label(can1, text="Username:", bg="#000000", fg="#ffffff", font=("Arial", 8))
      lab1.place(x=60, y=30)
      et1 = Entry(can1, textvariable=user1, width="60", bg="#000000", fg="#ffffff", font=("Arial", 10))
      et1.place(x=130, y=30)
      btn1 = Label(can1, text="Log In", bg="#292929", fg="#ffffff", font=("Arial", 11))
      btn1.place(x=290, y=70)
      def b_e(e):
           btn1.config(bg="#d0940a")
      def b_l(e):
           btn1.config(bg="#292929")
      def b_b(e):
           if user1.get()=="":
                messagebox.showwarning("Error", "Please fill the username.")
           else:
               user_ = user1.get()
               ret = Git.Git.config_git(user_)
               if ret==0:
                   messagebox.showwarning("Error", "Unable to configure.")
               else:
                os.mkdir("~temp")
                page2.page_2x.add_it(par_, user_, cl_)
                can1.place_forget()
                cl_.place_forget()
      btn1.bind('<Enter>', b_e)
      btn1.bind('<Leave>', b_l)
      btn1.bind('<Button-1>', b_b)
      
      